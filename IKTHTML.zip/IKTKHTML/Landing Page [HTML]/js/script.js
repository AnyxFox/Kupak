const header = document.getElementById("head")
const mt = document.getElementById("mt")
const st = document.getElementById("st")
const sti = document.getElementById("sti")
const thebtn = document.getElementById("clickable")
const ftr = document.getElementById("ftr")
const nav = document.getElementById("nav")

window.onload = function() {
    header.classList.add('slideout');
    mt.classList.add('mtupslide');
    st.classList.add('stupslide')
    sti.classList.add('stiupslide')
    thebtn.classList.add("pupslide")
    ftr.classList.add("ftrupslide")
    nav.classList.add("navdownslide")
    setTimeout(function() {
        header.classList.remove('slideout');
        mt.classList.remove('mtupslide');
        ftr.classList.remove("ftrupslide")
        nav.classList.remove("navdownslide")
    }, 1500);
    setTimeout(function() {
        st.classList.add('stupslide')
    }, 2500);
    setTimeout(function() {
        sti.classList.add('stiupslide')
    }, 4500);
    setTimeout(function() {
        thebtn.classList.add("pupslide")
    }, 3500);
};